export default function Navbar() {
  return (
    <nav className="w-full p-4 bg-white border-b">
      <h1 className="text-xl font-bold">vTry It</h1>
    </nav>
  );
}