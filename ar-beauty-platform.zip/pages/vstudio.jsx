export default function VStudio() {
  return (
    <div className="min-h-screen p-8 bg-pink-50">
      <h1 className="text-2xl font-semibold">vStudio - Explore AR Effects</h1>
    </div>
  );
}