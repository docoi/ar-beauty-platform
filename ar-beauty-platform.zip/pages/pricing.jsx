export default function PricingPage() {
  return (
    <div className="min-h-screen p-8 bg-white">
      <h1 className="text-2xl font-bold mb-4">Pricing Plans</h1>
      <p>Compare tiers and choose what suits your creator journey.</p>
    </div>
  );
}