export default function ContactPage() {
  return (
    <div className="min-h-screen p-8 bg-white">
      <h1 className="text-2xl font-bold mb-4">Contact Us</h1>
      <p>We’d love to hear from you.</p>
    </div>
  );
}