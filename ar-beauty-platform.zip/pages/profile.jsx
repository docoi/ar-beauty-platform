export default function ProfilePage() {
  return (
    <div className="min-h-screen p-8 bg-white">
      <h1 className="text-2xl font-bold">My Profile</h1>
    </div>
  );
}