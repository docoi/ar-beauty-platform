export default function Dashboard() {
  return (
    <div className="min-h-screen p-8 bg-gray-50">
      <h1 className="text-2xl font-bold">Client Dashboard</h1>
    </div>
  );
}