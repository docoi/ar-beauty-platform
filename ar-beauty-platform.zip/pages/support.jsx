export default function SupportPage() {
  return (
    <div className="min-h-screen p-8 bg-white">
      <h1 className="text-2xl font-bold">Support & Tutorials</h1>
    </div>
  );
}